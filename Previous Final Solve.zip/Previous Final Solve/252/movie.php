<?php
function calculateMovieNight(
    int $attendees,
    int $capacity,
    int $ticketPrice
): void {

    if ($attendees <= 0 || $capacity <= 0 || $ticketPrice < 0) {
        echo "Invalid input values.";
        return;
    }

    $screens = (int) ceil($attendees / $capacity);

    $totalSeats = $screens * $capacity;
    $emptySeats = $totalSeats - $attendees;

    $wastedMoney = $emptySeats * $ticketPrice;

    $rentalCost = $screens * 25000;

    echo "<h2>Movie Night Report</h2>";
    echo "Total Screens: " . $screens . "<br>";
    echo "Empty Seats: " . $emptySeats . "<br>";
    echo "Wasted Money: BDT " .
        number_format($wastedMoney) . "<br>";
    echo "Total Rental Cost: BDT " .
        number_format($rentalCost);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $attendees = (int) $_POST["attendees"];
    $capacity = (int) $_POST["capacity"];
    $ticketPrice = (int) $_POST["ticketPrice"];

    calculateMovieNight($attendees, $capacity, $ticketPrice);
}
?>