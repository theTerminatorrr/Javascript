<?php
function calculateBudget($attendees, $costPerPerson, $capacity)
{
    if ($attendees <= 0 || $costPerPerson < 0 || $capacity <= 0) {
        echo "Invalid input.";
        return;
    }

    $totalVenues = ceil($attendees / $capacity);

    $emptySeats = ($totalVenues * $capacity) - $attendees;

    $wastedMoney = $emptySeats * $costPerPerson;

    echo "<h2>Venue Budget Result</h2>";
    echo "Total Venues: " . $totalVenues . "<br>";
    echo "Empty Seats: " . $emptySeats . "<br>";
    echo "Wasted Money: " . number_format($wastedMoney, 2) . " BDT";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $attendees = (int) $_POST["attendees"];
    $costPerPerson = (int) $_POST["cost"];
    $capacity = (int) $_POST["capacity"];

    calculateBudget($attendees, $costPerPerson, $capacity);
}
?>