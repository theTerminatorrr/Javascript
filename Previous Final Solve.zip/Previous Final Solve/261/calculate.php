<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $distance = (float) $_POST["distance"];
    $energyPerMeter = (float) $_POST["energy_per_meter"];
    $capacity = (float) $_POST["capacity"];

    if (
        !is_finite($distance) ||
        !is_finite($energyPerMeter) ||
        !is_finite($capacity) ||
        $distance <= 0 ||
        $energyPerMeter <= 0 ||
        $capacity <= 0
    ) {
        die("All inputs must be positive finite numbers.");
    }

    $totalEnergy = $distance * $energyPerMeter;

    $modules = ceil($totalEnergy / $capacity);

    $totalCarriedEnergy = $modules * $capacity;

    $unusedEnergy = $totalCarriedEnergy - $totalEnergy;

    $unusedPercentage =
        ($unusedEnergy / $totalCarriedEnergy) * 100;

    if ($unusedPercentage <= 10) {
        $status = "Efficient";
    } elseif ($unusedPercentage <= 25) {
        $status = "Acceptable";
    } else {
        $status = "Wasteful";
    }

    echo "<h2>Mars Rover Battery Report</h2>";
    echo "Total Energy Required: " .
        round($totalEnergy, 2) . "<br>";

    echo "Battery Modules Needed: " .
        $modules . "<br>";

    echo "Unused Energy Capacity: " .
        round($unusedEnergy, 2) . "<br>";

    echo "Battery Usage Status: " .
        $status . "<br>";
}
?>