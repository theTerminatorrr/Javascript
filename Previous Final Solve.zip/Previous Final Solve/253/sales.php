<?php
$itemsPerDay = (int) $_POST['items'];
$days = (int) $_POST['days'];
$target = (int) $_POST['target'];

$totalSold = $itemsPerDay * $days;

if ($totalSold >= 500) {
    $performance = "Excellent";
} elseif ($totalSold >= 300) {
    $performance = "Good";
} elseif ($totalSold >= 150) {
    $performance = "Average";
} else {
    $performance = "Poor";
}

if ($totalSold > $target) {
    $difference = $totalSold - $target;
    $result = "Above target by " . $difference . " items";
} elseif ($totalSold < $target) {
    $difference = $target - $totalSold;
    $result = "Below target by " . $difference . " items";
} else {
    $result = "Target met exactly (0 difference)";
}

echo "<h2>Sales Report</h2>";
echo "Total Items Sold: " . $totalSold . "<br>";
echo "Performance: " . $performance . "<br>";
echo "Target Items: " . $target . "<br>";
echo "Result: " . $result;
?>