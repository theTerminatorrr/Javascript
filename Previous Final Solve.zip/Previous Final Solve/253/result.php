<?php
$ct1 = (float) $_POST['ct1'];
$ct2 = (float) $_POST['ct2'];
$ct3 = (float) $_POST['ct3'];

$midterm = (float) $_POST['midterm'];
$final = (float) $_POST['final'];

$ctMarks = [$ct1, $ct2, $ct3];

rsort($ctMarks);

$bestTwoAverage = ($ctMarks[0] + $ctMarks[1]) / 2;

$total = $bestTwoAverage + $midterm + $final;

if ($total > 54) {
    $status = "Passed";
} else {
    $status = "Failed";
}

echo "<h2>Student Result</h2>";
echo "Best Two CT Average: " .
    number_format($bestTwoAverage, 2) . "<br>";

echo "Midterm Mark: " . $midterm . "<br>";
echo "Final Exam Mark: " . $final . "<br>";

echo "Total Marks: " .
    number_format($total, 2) . "<br>";

echo "Status: " . $status;
?>